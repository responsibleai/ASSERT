#ifndef AGENT_CONTROL_SPECIFICATION_H
#define AGENT_CONTROL_SPECIFICATION_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct AcsBuilder AcsBuilder;
typedef struct AcsRuntime AcsRuntime;

typedef void (*AcsFreeResultCallback)(char *ptr, void *user_data);

typedef char *(*AcsAnnotatorCallback)(
    const char *annotator_name,
    const char *annotator_json,
    const char *preliminary_policy_input_json,
    void *user_data);

typedef char *(*AcsPolicyCallback)(
    const char *prepared_invocation_json,
    void *user_data);

/*
 * Error strings returned through char **err are allocated by ACS.
 * Free populated error strings with acs_free_string.
 *
 * Artifact kits expose this ABI through libagent_control_specification_core.so.
 * Python and Node native extensions are SDK implementation details and may have
 * additional runtime dependencies when loaded by non-SDK hosts.
 *
 * acs_builder_from_path resolves relative manifest resources, including Rego
 * bundles and file-based extends, against the manifest file location.
 * acs_builder_from_yaml and acs_builder_from_yaml_chain do not carry a base
 * directory. Relative manifest resources in YAML strings are resolved against
 * the host process current working directory. Change cwd or prefer
 * acs_builder_from_path when loading manifests with relative resources.
 */
AcsBuilder *acs_builder_from_path(const char *path, char **err);
AcsBuilder *acs_builder_from_yaml_chain(const char *const *yamls, size_t n, char **err);
AcsBuilder *acs_builder_from_yaml(const char *yaml, char **err);
AcsBuilder *acs_builder_from_json(const char *json, char **err);

/*
 * Registered callbacks and user_data must remain valid and thread safe for the
 * lifetime of the built runtime. Callback return strings are owned by the host
 * and are released by ACS through the paired AcsFreeResultCallback.
 */
int acs_builder_register_annotator_dispatcher(
    AcsBuilder *builder,
    AcsAnnotatorCallback callback,
    AcsFreeResultCallback free_result,
    void *user_data,
    char **err);

int acs_builder_register_policy_dispatcher(
    AcsBuilder *builder,
    AcsPolicyCallback callback,
    AcsFreeResultCallback free_result,
    void *user_data,
    char **err);

/*
 * These functions are exported only by builds compiled with default dispatchers.
 */
int acs_builder_enable_default_annotator_dispatcher(AcsBuilder *builder, char **err);
int acs_builder_enable_default_policy_dispatcher(AcsBuilder *builder, char **err);

/*
 * Perf telemetry levels use the wire values Off 0, External 1, and Full 2.
 */
int acs_builder_set_perf_telemetry(AcsBuilder *builder, int level, char **err);

/*
 * Builds a runtime and consumes builder on success or failure.
 * Do not call acs_builder_free or any builder function after this call returns.
 */
AcsRuntime *acs_builder_build(AcsBuilder *builder, char **err);

/*
 * Frees a builder that has not been consumed by acs_builder_build.
 * This function is null safe.
 */
void acs_builder_free(AcsBuilder *builder);

/*
 * request_json is a NUL-terminated UTF-8 string. A well formed request is a
 * JSON object with intervention_point and snapshot fields plus an optional mode
 * field that defaults to enforce. Malformed JSON or malformed request objects
 * return a JSON deny verdict with runtime_error:request_invalid. Null or
 * non-UTF-8 pointers remain ABI errors reported through err. The returned JSON
 * string is allocated by ACS and must be freed with acs_free_string.
 */
char *acs_runtime_evaluate(const AcsRuntime *runtime, const char *request_json, char **err);

/*
 * Escalation is returned as an escalate verdict. This ABI does not register an
 * approval resolver callback. Hosts either handle approval around the returned
 * verdict or use an SDK approval seam.
 */

/*
 * Frees a runtime returned by ACS.
 * This function is null safe.
 */
void acs_runtime_free(AcsRuntime *runtime);

/*
 * Frees strings returned by ACS.
 * This function is null safe.
 */
void acs_free_string(char *string);

#ifdef __cplusplus
}
#endif

#endif
