pub(crate) mod annotation {
    pub(crate) const FROM: &str = "from";
    pub(crate) const INPUT_FROM: &str = "input_from";
    pub(crate) const TYPE: &str = "type";
}

/// Reserved deny reasons that cross the dispatcher boundary, where a host
/// supplied annotator dispatcher signals the outcome back to the runtime. These
/// are the single source of truth for the sentinel strings, so the FFI boundary
/// and the language bridges compare and emit the same values without duplicating
/// string literals that could drift apart.
pub mod reserved_reason {
    pub const ANNOTATION_TIMEOUT: &str = "runtime_error:annotation_timeout";
    pub const ANNOTATION_FAILED: &str = "runtime_error:annotation_failed";
}

pub(crate) mod engine {
    pub(crate) const CUSTOM: &str = "custom";
    pub(crate) const REGO: &str = "rego";
    pub(crate) const TEST: &str = "test";
}

pub(crate) mod policy_input {
    pub(crate) const ANNOTATIONS: &str = "annotations";
    pub(crate) const INTERVENTION_POINT: &str = "intervention_point";
    pub(crate) const KIND: &str = "kind";
    pub(crate) const PATH: &str = "path";
    pub(crate) const SNAPSHOT: &str = "snapshot";
    pub(crate) const POLICY_TARGET: &str = "policy_target";
    pub(crate) const TOOL: &str = "tool";
    pub(crate) const VALUE: &str = "value";
}
