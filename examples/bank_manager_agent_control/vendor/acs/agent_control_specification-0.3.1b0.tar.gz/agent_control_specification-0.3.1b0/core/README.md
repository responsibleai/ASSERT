# Agent Control Specification

Agent Control Specification, ACS, is a portable contract for governing AI agents across their full lifecycle. It provides a stateless, deterministic policy decision runtime for agent security.

Define once. Enforce everywhere.

---

## Why ACS

Agents are no longer just generating text.  
They retrieve data, call tools, and execute actions across systems.

As agents become more autonomous, a new question emerges:

Who governs what an agent is allowed to do across its entire lifecycle?

Today, governance is fragmented:
- Policies are embedded in prompts, code, or framework hooks  
- Enforcement is inconsistent across systems  
- Security teams lack centralized visibility or control  

There is no standard way to define what an agent policy actually is.

---

## What ACS is

ACS is a portable, lifecycle-aware policy contract for AI agents.

It defines:
- what to validate across input, state, tools, and output  
- when policies should be evaluated  
- how decisions are structured and composed  
- what evidence is captured for audit  

All of this lives in a centralized configuration.

Instead of scattering logic across prompts, middleware, and application code, ACS unifies governance into one contract.

---

## Core idea

A single policy artifact covers the full agent loop:

```
Input → Model → Tool Call → Tool Result → Output
```

---

## Example

```yaml
agent_control_specification_version: "0.3.1-beta"
metadata:
  name: email-agent
policies:
  email_policy:
    type: rego
    bundle: ./policy
    query: data.email_agent.verdict
intervention_points:
  pre_tool_call:
    policy_target: "$.tool_call.args"
    policy_target_kind: tool_args
    tool_name_from: "$.tool_call.name"
    policy:
      id: email_policy
tools:
  send_email:
    type: Tool
    id: send_email
    clearance: internal
```

---

## Project status

| Item | Value |
| --- | --- |
| Status | Beta and draft |
| Specification version | `0.3.1-beta` |
| Normative spec | [`spec/SPECIFICATION.md`](spec/SPECIFICATION.md) |
| Threat model | [`docs/security-model.md`](docs/security-model.md) |

New to ACS? [`QUICKSTART.md`](QUICKSTART.md) is a step by step guide to integrating ACS enforcement into an agent host.

## Core properties

| Property | Runtime contract |
| --- | --- |
| Stateless | The runtime retains no mutable state that influences later verdicts. The host supplies the complete snapshot for every call. |
| Deterministic | The same manifest, snapshot, mode, and dispatcher outputs produce the same verdict and transformed policy target. |
| Fail closed | Runtime failures return `deny`, use a reserved runtime error reason, and apply no effect. |

The model is specified in [`spec/SPECIFICATION.md`](spec/SPECIFICATION.md). Security boundaries and host obligations are described in [`docs/security-model.md`](docs/security-model.md).
Layer ownership is described in [`docs/architecture.md`](docs/architecture.md).

## Intervention points

| Intervention point | Use |
| --- | --- |
| `agent_startup` | Evaluate agent or session startup metadata before the run begins. |
| `input` | Evaluate external request ingress before the agent loop begins. |
| `pre_model_call` | Evaluate model request messages, context, and tool definitions before the model call. |
| `post_model_call` | Evaluate the model response before the host acts on it. |
| `pre_tool_call` | Evaluate one concrete tool invocation before execution. |
| `post_tool_call` | Evaluate one concrete tool result before it returns to the agent or caller. |
| `output` | Evaluate the assembled final user visible response. |
| `agent_shutdown` | Evaluate agent or session shutdown metadata and summaries. |

`pre_tool_call` and `post_tool_call` are the only tool intervention points and the only points that accept `tool_name_from`.

## Zero-config construction

Every SDK exposes a single `from_path` constructor that loads a manifest and wires bundled dispatchers at the host integration layer, so a host that uses Rego policies and either declares no annotators or configures real annotator endpoints integrates in roughly three lines. The bundled OPA policy dispatcher resolves the manifest-relative Rego bundle and shells to a local `opa` binary. `$ACS_OPA_PATH`, when set, is authoritative and must point to the OPA binary or its containing directory. If it is unset, Node hosts try the per-platform `agent-control-specification-opa-*` optional dependency before relying on a system `opa` on `PATH`, while other SDKs rely on `PATH`. The bundled annotator dispatcher routes each annotator by its `type` to the bundled classifier, LLM, or endpoint implementation. These defaults are outside the pure decision core described in [`docs/architecture.md`](docs/architecture.md).

```rust
let control = AgentControl::from_path("manifest.yaml")?;
```

```python
control = AgentControl.from_path("manifest.yaml")
```

```typescript
const control = AgentControl.fromPath("manifest.yaml");
```

```csharp
var control = AgentControl.FromPath("manifest.yaml");
```

Use `from_path` when the manifest uses Rego policies and the annotators either are absent or point at configured endpoints with credentials. Supply custom dispatchers through the `*_with_dispatchers` constructors (Rust) or the optional dispatcher arguments (Python, Node, .NET) when annotators are local, deterministic, mocked, or offline, or when policy outputs need host-specific post-processing. An explicitly supplied dispatcher always overrides the bundled default, and the two dispatchers default independently, so a host can take the bundled OPA policy dispatcher while supplying its own annotator dispatcher.

One constraint follows from the bundled defaults. The bundled classifier, LLM, and endpoint annotators issue network calls, so a zero-config annotator requires a reachable endpoint or provider plus any credentials it needs. Endpoint annotators send the selected input plus a sanitized non-transport fields map, never credential or endpoint configuration fields, and require a JSON object response. Redaction needs no custom dispatcher. A Rego policy emits a `redact` effect with a `pattern` regex or a `values` literal list, and the core resolves it into Unicode scalar value offset spans, not UTF-8 bytes, UTF-16 code units, or grapheme clusters, before applying it. Pattern-driven and value-driven redaction work under zero-config. The repository checkout path `examples/support_agent` shows a Rego policy that redacts PII through pattern `redact` effects with no host span computation.

## Quickstart with Rust and Rego

This example is reduced from repository checkout path `examples/ifc_agent`. It uses the bundled OPA dispatcher and evaluates one `pre_tool_call` snapshot.

`manifest.yaml`

```yaml
agent_control_specification_version: "0.3.1-beta"
metadata:
  name: "ifc-agent"
policies:
  ifc_policy:
    type: rego
    bundle: ./policy
    data_paths:
      - ../../policy/lib
    query: data.agent_control_specification.ifc_agent.verdict
intervention_points:
  pre_tool_call:
    policy_target: "$.tool_call.args"
    policy_target_kind: tool_args
    tool_name_from: "$.tool_call.name"
    policy:
      id: ifc_policy
      query: data.agent_control_specification.ifc_agent.pre_tool_call_verdict
tools:
  public_egress:
    type: Tool
    id: public_egress
    clearance: public
    security_labels: [external]
```

`policy/ifc_agent.rego`

```rego
package agent_control_specification.ifc_agent

import data.agent_control_specification.lib.ifc
import rego.v1

default verdict := {"decision": "allow"}

default pre_tool_call_verdict := {"decision": "allow"}

verdict := pre_tool_call_verdict if {
	input.intervention_point == "pre_tool_call"
}

source_labels := object.get(object.get(input.snapshot, "ifc", {}), "source_labels", [])

sink_clearance := object.get(input.tool, "clearance", "")

pre_tool_call_verdict := ifc.verdict(sink_clearance, source_labels) if {
	input.intervention_point == "pre_tool_call"
}
```

Rust host call reduced from repository checkout path `examples/ifc_agent/demo.rs`

```rust
use agent_control_specification::{
    AgentControl, Decision, EnforcementMode, InterventionPoint,
};
use serde_json::json;
use std::{env, path::Path};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let sdk_dir = Path::new(env!("CARGO_MANIFEST_DIR"));
    let example_dir = sdk_dir.join("../../examples/ifc_agent").canonicalize()?;
    env::set_current_dir(&example_dir)?;

    // Zero-config construction. The manifest declares a Rego policy bundle and no
    // annotators, so from_path wires the bundled OPA policy dispatcher against the
    // manifest-relative bundle with no host dispatcher code.
    let control = AgentControl::from_path("manifest.yaml")?;

    let denied = control.evaluate_intervention_point(
        InterventionPoint::PreToolCall,
        json!({
            "ifc": {"source_labels": ["confidential"]},
            "tool_call": {
                "id": "tool-call-1",
                "name": "public_egress",
                "args": {"body": "customer account balance"}
            }
        }),
        EnforcementMode::Enforce,
    );

    assert_eq!(denied.verdict.decision, Decision::Deny);
    assert_eq!(
        denied.verdict.reason.as_deref(),
        Some("ifc_clearance_violation")
    );

    println!("demo verification: PASS");
    Ok(())
}
```

`from_path` resolves the manifest and, at the SDK integration layer, wires the bundled OPA policy dispatcher against the manifest-relative Rego bundle and supplies a default annotator dispatcher. Manifest loading may read files and fetch HTTPS `extends` during construction. Intervention point evaluation remains stateless and performs no network I/O except through host supplied dispatchers. A host that needs custom annotation logic or custom policy evaluation supplies its own dispatchers through `AgentControl::from_path_with_dispatchers`. See [Zero-config construction](#zero-config-construction).

In a repository checkout, run the `ifc_agent` example with Cargo to verify the complete IFC demo.

## Manifest schema overview

| Block | Meaning |
| --- | --- |
| `agent_control_specification_version` | Non empty version string. The current spec describes `0.3.1-beta`. |
| `metadata` | Free form manifest metadata. |
| `extends` | Ordered parent manifest paths or HTTPS URLs merged before the child manifest. |
| `policies` | Named policy definitions. Supported types are `rego`, `test`, and `custom`. |
| `intervention_points` | Closed map keyed by the eight intervention point names. Each entry binds one policy. |
| `tools` | Catalog of projected tool metadata. Entries accept arbitrary fields including `clearance` and `security_labels`. |
| `annotators` | Declarations for named annotators with type `classifier`, `llm`, or `endpoint`. |

| Intervention point field | Meaning |
| --- | --- |
| `policy_target` | Snapshot path for the value under evaluation. |
| `policy_target_kind` | Optional descriptive label copied into the policy input. |
| `annotations` | Per point opt in map for declared annotators and their `from` paths. |
| `policy` | Binding with `id`, optional `query`, and host defined adapter fields. |
| `tool_name_from` | Snapshot path for current tool name on tool intervention points only. |

Manifest details are in specification sections 9 and 11. Repository checkouts also contain the implementation in `core/src/manifest.rs`.

## Policies

| Policy type | Runtime behavior |
| --- | --- |
| `rego` | Prepared as a `RegoPolicyInvocation` and executable with `OpaPolicyDispatcher` when OPA is available. |
| `test` | Fixed test double path for runtime tests. |
| `custom` | Host dispatcher path identified by a required `adapter` string. |

A policy binding selects one policy by `policy.id`. Rego policies require a query either on the policy definition or the binding. The bundled OPA runner calls `opa eval --format json --stdin-input`, passes `bundle` as `--bundle`, and passes `data` or `data_paths` as `--data`.

| Verdict member | Meaning |
| --- | --- |
| `decision` | Required value of `allow`, `deny`, `warn`, or `escalate`. |
| `reason` | Optional low cardinality code. Policy output must not use the runtime error prefix. |
| `message` | Optional host facing text. |
| `effects` | Optional array of policy target scoped effects. |

## Annotators

ACS core declares annotator types and dispatches through host owned implementations. `classifier`, `llm`, and `endpoint` are the supported manifest types. The runtime resolves each point specific `from` path against the preliminary policy input, calls the dispatcher, and writes the returned value only under `annotations.<name>`.

| Integration | Path |
| --- | --- |
| Reference classifier dispatcher | Repository checkout path `core/src/dispatchers/classifier.rs` |
| Reference LLM judge dispatcher | Repository checkout path `core/src/dispatchers/llm.rs` |
| LLM provider preset guide | [`docs/llm-annotator-providers.md`](docs/llm-annotator-providers.md) |
| Reference endpoint dispatcher | Repository checkout path `core/src/dispatchers/endpoint.rs` |
| Bundled AACS provider | Feature `aacs`, provider `aacs`, type `AacsProvider` |
| AACS usage example | Repository checkout path `integrations/annotators/examples/live_aacs_classifier.rs` |

## Extends composition

File based loaders resolve `extends` entries relative to the including manifest, merge parents before children, clear resolved `extends`, and validate the result. Relative paths are confined to the allowed root established by the top level manifest. HTTPS URL entries are fetched during manifest loading with no ambient credentials, finite timeout, body size, and redirect limits, and HTTPS only redirect enforcement. Plain `http` and non HTTPS schemes fail closed. A URL string fetches without a hash pin. A URL object may carry `integrity` set to `sha256-<base64>` or `sha256` set to hexadecimal text to pin fetched bytes. URL fetches use the platform trust store and do not expose an SDK option for custom local CA roots. Cycles, failed fetches, hash mismatches, missing files, version conflicts, and conflicting duplicate definitions fail closed.

| SDK | Loader entry points |
| --- | --- |
| Rust | `Manifest::from_path`, `Manifest::from_yaml_chain`, `Manifest::merge_chain` |
| Python | `NativeRuntimeClient.from_path`, `NativeRuntimeClient.from_manifest_chain`, native `from_path`, native `from_manifest_chain` |
| Node | `AgentControl.fromPath`, `AgentControl.fromManifestChain`, native `fromPath`, native `fromManifestChain` |
| .NET | `AgentControl.FromPath`, `AgentControl.FromManifestChain`, `NativeAgentControlRuntime.FromPath`, `NativeAgentControlRuntime.FromManifestChain` |

## Information Flow Control

ACS implements IFC as a stateless label flow policy model. The host tracks provenance and supplies source labels in `input.snapshot.ifc.source_labels`. The manifest declares sink metadata in the tool catalog. The reusable Rego library at repository checkout path `policy/lib/ifc.rego` defines the default lattice `public < internal < confidential < secret` and denies no write down flows unless sink clearance dominates all source labels.

| IFC path | Role |
| --- | --- |
| `input.snapshot.ifc.source_labels` | Policy input location for host supplied source labels. |
| `input.tool.clearance` | Projected tool sink clearance from the manifest. |
| `input.tool.security_labels` | Projected tool sink labels from the manifest. |
| Repository checkout path `examples/ifc_agent` | Runnable Rust and Rego IFC demo. |
| [`docs/ifc-label-flow.md`](docs/ifc-label-flow.md) | Design note for label flow and host responsibilities. |

## Observability

The Rust core emits structured telemetry through `TelemetrySink`. Event kinds include `decision`, `annotator_dispatch`, `policy_evaluation`, `evaluation_timing`, `effect_applied`, `annotator_failed`, and `policy_failed`. The OpenTelemetry bridge is the `agent_control_specification_otel` integration crate. It provides `OtelTelemetrySink` and emits counters such as `acs_intervention_allow_total` plus the `acs_intervention_duration_ms` histogram. The content safe event model is described in `observability.md` in artifact kits and `docs/observability.md` in repository checkouts. Native SDK package surfaces expose the `PerfTelemetry` level for runtime timing, while exporter sinks remain host or integration responsibilities.

| PerfTelemetry mode | Wire value | Behavior |
| --- | --- | --- |
| `Off` | `0` | No external or stage timing perf events. |
| `External` | `1` | Annotator dispatch and policy evaluation cost events. |
| `Full` | `2` | External events plus per evaluation timing. |

Telemetry defaults are content redacted. Events include stable fields such as `reason_code`, error class, action identity, policy id, annotator names, decisions, modes, and durations. Events omit raw policy targets, tool arguments, model output, annotation payloads, secrets, and personal data.

## SDK matrix

| SDK | Native binding | Artifact install | Artifact smoke |
| --- | --- | --- | --- |
| Rust | Direct Rust crate over `agent_control_specification_core` | Add local `.crate` artifacts to a temporary crate with `[patch.crates-io]` paths. | Evaluate one manifest from the temporary host crate. |
| Python | PyO3 extension built by maturin | Install the wheel from `artifacts/` into a temporary virtual environment. | Call `NativeRuntimeClient.from_path` and evaluate one allow and one deny case. |
| Node | napi-rs addon built by `@napi-rs/cli` | Install the `.tgz` package from `artifacts/` into a temporary project. | Call `AgentControl.fromPath` and evaluate one allow and one deny case. |
| .NET | P/Invoke over `libagent_control_specification_core` | Restore from the local nupkg source in `artifacts/`. | Call `AgentControl.FromPath` and evaluate one allow and one deny case. |

The native C ABI is declared in `core/include/agent_control_specification.h` in repository checkouts and copied to `artifacts/include/agent_control_specification.h` in artifact kits. Artifact kits also include the standalone core shared library `libagent_control_specification_core.so` for C ABI hosts. Do not load the Python PyO3 extension as the C ABI library unless you are embedding Python and supplying its runtime symbols. Strings returned by ACS must be freed with `acs_free_string`. Host callback return strings are freed by ACS through the paired host `AcsFreeResultCallback`. `acs_builder_build` consumes the builder on success or failure, so hosts must not call `acs_builder_free` or any other builder function after `acs_builder_build` returns. Malformed UTF-8 request envelopes return a fail closed `runtime_error:request_invalid` verdict when ACS can return JSON, while null or non UTF-8 pointers remain ABI errors. Prefer `acs_builder_from_path` for manifests with relative `bundle` paths or file-based `extends`, since YAML string constructors resolve relative resources against the host process current working directory. The C ABI returns `escalate` verdicts but does not provide a host approval resolver callback. Hosts that need approval resolution should handle escalation around the C ABI result or use an SDK approval seam.

## Framework adapters

Every SDK ships the same base enforcement surface, so any framework can be guarded without a dedicated adapter. The base surface is the generic `input`/`output`, `pre_model_call`/`post_model_call`, and `pre_tool_call`/`post_tool_call` wrappers plus the `escalate` approval seam. On top of that base, each SDK ships first-class adapters for the frameworks that have a first-party package in that language, so a host wraps a real framework object in one call and keeps ACS enforcement on every model and tool boundary.

| SDK | First-class framework adapters |
| --- | --- |
| Python | LangChain, OpenAI Agents SDK, OpenAI client, Anthropic, AutoGen, Semantic Kernel, CrewAI, LiteLLM proxy, MCP |
| Node | LangChain, OpenAI Agents SDK, Anthropic, MCP, GitHub Copilot permission hook, OpenClaw |
| .NET | No-dependency `IAgentControlChatClient` and MCP shapes in the base package, with companion packages for real `Microsoft.Extensions.AI` `IChatClient`, AutoGen, Semantic Kernel, and Microsoft Agent Framework objects |
| Rust | `agent_control_specification_openai` over `async-openai`, `agent_control_specification_mcp` over `rmcp`, Rig (which covers Anthropic through its provider) |

Python LangChain hosts use `guard_langchain_runnable` for async Runnable objects and `guard_langchain_tool` for async tool objects. Runnable wrappers mediate `ainvoke(...)` through `input` and `output`. Tool wrappers mediate `ainvoke(...)` through `pre_tool_call` and `post_tool_call`. Sync and batch entry points are blocked by the adapter instead of bypassing ACS.

```python
from agent_control_specification import (
    AgentControl,
    guard_langchain_runnable,
    guard_langchain_tool,
)

control = AgentControl.from_path("manifest.yaml")

guarded_chain = guard_langchain_runnable(control, chain)
answer = await guarded_chain.ainvoke({"question": "Summarize the policy"})

guarded_tool = guard_langchain_tool(
    control,
    retriever_tool,
    tool_call_id="rag-retrieve-1",
)
documents = await guarded_tool.ainvoke({"query": "public docs"})
```

Node MCP hosts wrap a tool provider with `wrapMcpToolProvider` or with the object returned by `createMcpToolProviderAdapter`. The provider must expose `callTool(...)` or `call_tool(...)`. ACS evaluates the call through `runTool`, passes transformed arguments to the provider, and returns transformed tool results to the host.

```js
import {
  AgentControl,
  createMcpToolProviderAdapter,
} from "agent-control-specification";

const control = AgentControl.fromPath("manifest.yaml");
const provider = {
  async callTool(request) {
    return { content: `read ${request.arguments.path}` };
  },
};

const guarded = createMcpToolProviderAdapter(control, {
  toolCallId: "mcp-file-read",
}).wrapProvider(provider);

await guarded.callTool({
  name: "read_file",
  arguments: { path: "README.md" },
});
```

A framework with no first-party package in a language is guarded through the base wrappers rather than a dedicated shape. The full per-framework matrix, the two-layer dependency split, and the rationale for each "base" or "n/a" cell are in [`docs/adapter-matrix.md`](docs/adapter-matrix.md).

## Generator

The generator under repository checkout path `generator/` is a Python CLI named `acs-generate`. It asks an OpenAI compatible language model for a constrained JSON policy plan, builds a manifest and Rego policy from that plan, validates the artifacts, and writes `manifest.yaml`, `policy/<slug>.rego`, and `report.md` to the selected output directory.

```sh
PYTHONPATH=generator python3 -m acs_generator --help
```

```sh
acs-generate \
  --prompt "Deny risky transfers and redact account identifiers" \
  --tool wire_transfer:confidential \
  --out generated/bank-agent
```

The command requires `--prompt` or `--prompt-file`, an output directory, and model configuration through flags or `ACS_GENERATOR_API_BASE`, `ACS_GENERATOR_API_KEY`, `ACS_GENERATOR_MODEL`, and `ACS_GENERATOR_API_VERSION`.

## Examples

| Example | Demonstrates |
| --- | --- |
| Repository checkout path `examples/README.md` | Example taxonomy, goal based selection, and smoke validation guidance. |
| Repository checkout path `examples/bank_agent` | Committed core fixtures, canonical policy inputs, lifecycle points, tool points, effects, and a stdlib Python demo. |
| Repository checkout path `examples/lifecycle_rego` | Full lifecycle mediation with zero-config Rego, allow, warn, deny, escalate, approval, and redaction. |
| Repository checkout path `examples/custom_dispatchers` | Offline classifier, endpoint, and LLM annotator dispatchers plus a custom policy dispatcher. |
| Repository checkout path `examples/manifest_extends` | File based manifest composition with inherited policies and workload specific intervention points. |
| Repository checkout path `examples/conformance_snapshots` | Fixture driven policy review with named snapshots and expected verdict metadata. |
| Repository checkout path `examples/coding_agent` | Rust host app, manifest `extends`, OPA policy, approvals, redaction, and streaming aggregation by the host. |
| Repository checkout path `examples/ifc_agent` | Stateless IFC label flow with Rust, OPA, and the shared IFC Rego library. |
| Repository checkout path `examples/records_agent` | .NET host app for a medical records assistant with model, tool, output, and approval flows. |
| Repository checkout path `examples/research_agent` | Node host app for web research tools with OPA, annotations, approvals, and redaction. |
| Repository checkout path `examples/support_agent` | Python host app for customer support policy enforcement with classifier annotations and tool enforcement. |

## Reserved reasons

| Convention | Meaning |
| --- | --- |
| `runtime_error:<code>` | Reserved reason namespace for runtime failures. |

Policies must not emit reasons with that prefix. See specification section 15 for the complete reserved table.

## Contributing

See `CONTRIBUTING.md` and `CODE_OF_CONDUCT.md` in repository checkouts.

## License

ACS is licensed under the MIT License. See `LICENSE` in repository checkouts.
