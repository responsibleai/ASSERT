"""Verify packaged files and rebuild local viewer caches."""

import hashlib
from pathlib import Path

from assert_ai.viewer_read_model import build_run_viewer_artifacts


root = Path(__file__).resolve().parent
for line in (root / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
    expected, relative = line.split("  ", 1)
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise ValueError(f"Invalid checksum path: {relative}")
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise ValueError(f"Packaged file differs from its checksum: {relative}")

runs = sorted(path.parent for path in root.glob("*/*/scores.jsonl"))
if len(runs) != 6:
    raise ValueError(f"Expected six presentation runs, found {len(runs)}")
for run in runs:
    build_run_viewer_artifacts(run)
    print(f"Viewer cache rebuilt: {run.parent.name}/{run.name}")
