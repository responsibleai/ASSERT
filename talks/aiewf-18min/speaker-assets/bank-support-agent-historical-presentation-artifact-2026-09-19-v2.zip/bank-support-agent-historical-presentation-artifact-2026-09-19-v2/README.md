# Toronto presentation viewer artifacts

Prompt-and-scenario projection of the published historical experiment. The active rows derive viewer-compatible impermissible/permissible nodes from the explicitly configured prompt metrics and retained scenario metrics while preserving the original judge explanations, citations, narratives, and metric values. Source rows are preserved as `scores.prompt.source-original.jsonl`, `scores.scenario.source-original.jsonl`, and `scores.source-original.jsonl`.

## Open in the ASSERT viewer

From this directory, using ASSERT commit `81747d6f` or a later commit that contains the viewer fix from PR #349:

```powershell
python rebuild_viewer_indexes.py
$env:ARTIFACTS_ROOT = (Get-Location).Path
Set-Location <ASSERT checkout>\viewer
npm ci
npm run dev -- --host 127.0.0.1 --port 5174
```

Use the Prompt and Scenario child rows. Parent rows pool their different applicability denominators.

**Not a current rerun or a cleared benchmark.**
